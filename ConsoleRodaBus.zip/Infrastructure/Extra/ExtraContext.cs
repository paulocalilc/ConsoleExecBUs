﻿namespace ConsoleExecBUs.Infrastructure.Extra
{
    public class ExtraContext
    {
        public string Usuario { get; }
        public string Senha { get; }

        public ExtraContext(string usuario, string senha)
        {
            Usuario = usuario;
            Senha = senha;
        }
    }
}
