﻿using ConsoleExecBUs.Interfaces;
using static ConsoleExecBUs.Core.ClasseExtra;

namespace ConsoleExecBUs.Infrastructure.Extra
{
    public class ExtraAdapter : IExtraAdapter
    {
        public void SendKeys(string comando)
        {
            PropMyScreen.MyScreen.SendKeys(comando);
        }

        public void MoveCursor(short linha, short coluna)
        {
            PropMyScreen.MyScreen.MoveTo(linha, coluna);
        }

        public string ReadArea(short linIni, short colIni, short linFim, short colFim)
        {
            return PropMyScreen.MyScreen
                .Area(linIni, colIni, linFim, colFim, null, 1)
                .Value
                .Trim();
        }

        public string ReadScreen()
        {
            return PropMyScreen.MyScreen
                .Area(1, 1, 25, 80, null, 1)
                .Value
                .Trim();
        }

        public void WaitHost(int tempo)
        {
            PropMyScreen.MyScreen.WaitHostQuiet(tempo);
        }


        public bool EstaProcessando()
        {
            return PropMyScreen.MyScreen.OIA.XStatus == 5;
        }

    }
}
