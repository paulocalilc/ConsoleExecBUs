﻿namespace ConsoleExecBUs.Interfaces
{
    public interface IExtraConnectionService
    {
        bool ValidaExtra();
        bool FnObjetosExtra();
        bool FnReconectar();
        bool FnLoginUsuario();
        bool AbreExtra();

    }
}
