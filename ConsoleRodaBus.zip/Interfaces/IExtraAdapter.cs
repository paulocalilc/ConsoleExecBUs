﻿namespace ConsoleExecBUs.Interfaces
{
    public interface IExtraAdapter
    {
        void SendKeys(string comando);

        void MoveCursor(short linha, short coluna);

        string ReadArea(short linIni, short colIni, short linFim, short colFim);

        string ReadScreen();

        void WaitHost(int tempo);
        bool EstaProcessando();
    }
}
